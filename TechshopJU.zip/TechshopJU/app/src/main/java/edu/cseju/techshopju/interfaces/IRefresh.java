package edu.cseju.techshopju.interfaces;

import edu.cseju.techshopju.model.Product;

public interface IRefresh {
    public void RefreshActivity();

    public void UpdateProduct(Product product);
}
