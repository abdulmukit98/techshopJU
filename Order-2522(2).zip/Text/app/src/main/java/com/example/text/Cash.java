package com.example.text;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Cash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cash);
    }
}